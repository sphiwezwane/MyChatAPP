/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mychatapp;

import java.util.Scanner;

// MyChatApp is the console application that collects registration input,
// shows confirmation or error messages, and then authenticates the user.
/**
 *
 * @author ST10534768
 */
public class MyChatApp {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        System.out.println("MyChatApp registration");
        System.out.println();

        System.out.print("Enter your first name: ");
        login.setFirstName(input.nextLine());

        System.out.print("Enter your last name: ");
        login.setLastName(input.nextLine());

        // Username must contain an underscore and be no more than five characters long
        boolean usernameValid = false;
        while (usernameValid == false) {
            System.out.print("Enter a username: ");
            login.setUsername(input.nextLine());

            if (login.checkUserName() == true) {
                System.out.println(login.usernameMessage());
                usernameValid = true;
            } else {
                System.out.println(login.usernameMessage());
            }
        }

        // Password must be eight characters long and include a capital letter, a number, and a special character
        boolean passwordValid = false;
        while (passwordValid == false) {
            System.out.print("Enter a password: ");
            login.setPassword(input.nextLine());

            if (login.checkPasswordComplexity() == true) {
                System.out.println(login.passwordMessage());
                passwordValid = true;
            } else {
                System.out.println(login.passwordMessage());
            }
        }

        // Cell number must include the +27 country code and a number no more than ten digits long
        boolean cellValid = false;
        while (cellValid == false) {
            System.out.print("Enter a South African cell phone number (for example +27838968976): ");
            login.setCellPhoneNumber(input.nextLine());

            if (login.checkCellPhoneNumber() == true) {
                System.out.println(login.cellPhoneMessage());
                cellValid = true;
            } else {
                System.out.println(login.cellPhoneMessage());
            }
        }

        System.out.println();
        System.out.println(login.registerUser());
        System.out.println();
        System.out.println("MyChatApp login");
        System.out.println();

        // Decision structure that verifies authentication before allowing access
        boolean loggedIn = false;
        while (loggedIn == false) {
            System.out.print("Enter your username: ");
            login.setEnteredUsername(input.nextLine());

            System.out.print("Enter your password: ");
            login.setEnteredPassword(input.nextLine());

            if (login.loginUser() == true) {
                System.out.println(login.returnLoginStatus());
                loggedIn = true;
            } else {
                System.out.println(login.returnLoginStatus());
            }
        }

        input.close();
    }
}
